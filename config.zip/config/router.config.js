
const basics = [
  {
    path: '/',
    routes: [{path:`/sop`,  component:'@/pages/Index/index'},
             {path:`/auth`, component:'@/pages/Auth/index'} ],
  },
]

export default [...basics];
